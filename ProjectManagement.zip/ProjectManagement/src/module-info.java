/**
 * 
 */
/**
 * 
 */
module ProjectManagement {
	requires java.sql;
}